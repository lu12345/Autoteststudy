# coding = utf-8
BASE_URL = "http://httpbin.org/"
IP_URL = "/ip"
LOCAL_IP = "182.142.111.170"
POST_TEST_URL = "/post"
